package utils

import pillowisgod.com.example.memorygame.R

val DEFAULT_ICONS = listOf(
    R.drawable.ic_anchor,
    R.drawable.ic_ball,
    R.drawable.ic_cloud,
    R.drawable.ic_dollarsign,
    R.drawable.ic_drop,
    R.drawable.ic_face,
    R.drawable.ic_grass,
    R.drawable.ic_music,
    R.drawable.ic_phone,
    R.drawable.ic_pig,
    R.drawable.ic_snowflake,
    R.drawable.ic_sun
)
